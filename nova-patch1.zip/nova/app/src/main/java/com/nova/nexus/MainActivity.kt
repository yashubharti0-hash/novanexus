package com.nova.nexus

import android.content.*
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.core.graphics.drawable.toBitmap
import androidx.room.Room
import kotlinx.coroutines.*
import java.time.LocalTime
import java.time.format.DateTimeFormatter

data class AppInfo(val label: String, val pkg: String, val icon: ImageBitmap)

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val db = Room.databaseBuilder(this, Db::class.java, "nova").build()
        setContent { Nova(db.dao(), getSharedPreferences("nova", 0)) }
    }
}

fun loadApps(c: Context): List<AppInfo> {
    val pm = c.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0).map {
        AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm).toBitmap(96, 96).asImageBitmap())
    }.filter { it.pkg != c.packageName }.sortedBy { it.label.lowercase() }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable fun Nova(dao: PrefDao, sp: SharedPreferences) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var apps by remember { mutableStateOf(listOf<AppInfo>()) }
    LaunchedEffect(Unit) { apps = withContext(Dispatchers.IO) { loadApps(ctx) } }
    val prefs by dao.all().collectAsState(emptyList())
    val pm = prefs.associateBy { it.pkg }
    var amoled by remember { mutableStateOf(sp.getBoolean("amoled", true)) }
    var drawer by remember { mutableStateOf(false) }
    var q by remember { mutableStateOf("") }
    var time by remember { mutableStateOf(LocalTime.now()) }
    LaunchedEffect(Unit) { while (true) { time = LocalTime.now(); delay(10_000) } }
    val glass = Color.White.copy(alpha = if (amoled) 0.08f else 0.18f)
    val bg = if (amoled) Color.Black.copy(0.85f) else Color(0xFF1B2540).copy(0.55f)
    fun launch(a: AppInfo) { ctx.packageManager.getLaunchIntentForPackage(a.pkg)?.let { ctx.startActivity(it) } }
    fun set(a: AppInfo, f: (AppPref) -> AppPref) = scope.launch { dao.put(f(pm[a.pkg] ?: AppPref(a.pkg))) }
    BackHandler(drawer) { drawer = false; q = "" }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(bg, Color(0xFF3A1C71).copy(if (amoled) 0.25f else 0.5f))))
        .pointerInput(Unit) { detectVerticalDragGestures { _, d -> if (d < -20) drawer = true else if (d > 20) { drawer = false; q = "" } } }
        .systemBarsPadding().padding(20.dp)) {
        if (!drawer) Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(time.format(DateTimeFormatter.ofPattern("HH:mm")), color = Color.White, fontSize = 64.sp, fontWeight = FontWeight.Thin)
                Text("Your Home. Your Style. Your Productivity.", color = Color.White.copy(0.6f), fontSize = 12.sp)
                TextButton({ amoled = !amoled; sp.edit().putBoolean("amoled", amoled).apply() }) { Text(if (amoled) "AMOLED ✓" else "AMOLED", color = Color.White) }
            }
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                val favs = apps.filter { pm[it.pkg]?.fav == true && pm[it.pkg]?.hidden != true }
                if (favs.isEmpty()) Text("Swipe up for apps · long-press an app to favorite", color = Color.White.copy(0.5f))
                favs.forEach { a -> Text(a.label, color = Color.White, fontSize = 30.sp, modifier = Modifier.combinedClickable(onClick = { launch(a) }, onLongClick = { set(a) { it.copy(fav = false) } })) }
                Spacer(Modifier.height(24.dp))
            }
        } else Row(Modifier.fillMaxSize()) {
            val shown = apps.filter { pm[it.pkg]?.hidden != true && it.label.contains(q, true) }
            val ls = rememberLazyListState()
            Column(Modifier.weight(1f)) {
                OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(glass), placeholder = { Text("Search apps") }, singleLine = true)
                LazyColumn(state = ls, modifier = Modifier.weight(1f)) {
                    items(shown, key = { it.pkg }) { a ->
                        var menu by remember { mutableStateOf(false) }
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(16.dp))
                            .combinedClickable(onClick = { launch(a); drawer = false }, onLongClick = { menu = true }).padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Image(a.icon, null, Modifier.size(40.dp)); Spacer(Modifier.width(16.dp))
                            Text(a.label, color = Color.White, fontSize = 20.sp)
                            DropdownMenu(menu, { menu = false }) {
                                DropdownMenuItem({ Text(if (pm[a.pkg]?.fav == true) "Remove favorite" else "Favorite") }, { set(a) { it.copy(fav = !it.fav) }; menu = false })
                                DropdownMenuItem({ Text("Hide") }, { set(a) { it.copy(hidden = true) }; menu = false })
                                DropdownMenuItem({ Text("App info") }, { menu = false
                                    ctx.startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:${a.pkg}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) })
                            }
                        }
                    }
                }
            }
            Column(Modifier.fillMaxHeight().padding(start = 6.dp), verticalArrangement = Arrangement.SpaceEvenly) {
                ('A'..'Z').forEach { c -> Text("$c", color = Color.White.copy(0.7f), fontSize = 11.sp, modifier = Modifier.clickable {
                    val i = shown.indexOfFirst { it.label.uppercase().startsWith(c) }; if (i >= 0) scope.launch { ls.animateScrollToItem(i) } }) }
            }
        }
    }
}
