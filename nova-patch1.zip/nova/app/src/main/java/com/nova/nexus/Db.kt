package com.nova.nexus

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "app_pref")
data class AppPref(
    @PrimaryKey val pkg: String,
    val fav: Boolean = false,
    val hidden: Boolean = false
)

@Dao
interface PrefDao {
    @Query("SELECT * FROM app_pref")
    fun all(): Flow<List<AppPref>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(p: AppPref)
}

@Database(entities = [AppPref::class], version = 1, exportSchema = false)
abstract class Db : RoomDatabase() {
    abstract fun dao(): PrefDao
}
